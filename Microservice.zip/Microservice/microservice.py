import requests

import re

from bs4 import BeautifulSoup

def get_song_name(url: str):
    """
    get_song_name connects to the passed url and searches for the id "songName"

    param url: url that is connected to
    return: returns the html element with id "songName"
    """
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an exception for HTTP errors
        html_content = response.text
        soup = BeautifulSoup(html_content, 'html.parser')
        songName = soup.find(id="songName")
        return songName
    except requests.exceptions.RequestException as e:
        print("Error fetching HTML:", e)
        return None


def parse_name(songName: str):
    """
    parse_name parses the passed string into words and replaces dashes with spaces. Calls cap_first.

    param songName: string to be parsed
    return: returns the final parsed and formatted string

    ex: "songName.mp3" becomes "Song Name"
    """
    if "." in songName:
        title = str(songName.split('.')[0])
    else:
        title = str(songName)

    temp = ""
    for char in title:
        upper = char.isupper()
        number = char.isnumeric() and not title[title.index(char) - 1].isnumeric()
        bracket = '[' in char or '(' in char
        if upper or number or bracket:
            temp += " " + char
        else:
            temp += char
    
    temp = re.sub("-+|_+", " ", temp)
    
    temp = cap_first(temp)
    
    title = temp
    return title


def cap_first(phrase: str):
    """
    cap_first breaks the passed string into words and capitalizes the first letter of each. Calls itself again if current word begins with bracket or parenthesis.

    param phrase: the string that is broken down
    return: returns a complete string of the capitalized words

    ex: "hello there" becomes "Hello There"
    """
    exceptions = {"of", "a", "the"}
    words = phrase.split()
    temp = []
    for word in words:
        if word[0] == "[" or word[0] == "(":
            word = word[0] + cap_first(word[1:])
        elif not word[0].isupper() and word.lower() not in exceptions:
            word = word[0].capitalize() + word[1:]
        temp.append(word)
    
    return ' '.join(temp)


def print_to_text(song: str, fileHandle: str):
    """
    print_to_text writes contents of passed song string to the file "fileHandle"

    param song: song that is written
    param fileHandle: file that is opened and written to
    return: n/a
    """
    with open(fileHandle, 'w') as file:
        file.write(str(song))


if __name__ == "__main__":
    url = "http://localhost:3000"
    songName = get_song_name(url)
    # songName = "songName.mp3"
    # songName = "under_the_moonlight7[firstEdition](live-performance).wav"
    if songName:
        str(songName)
        song = parse_name(songName)
        file = "song_title.txt"
        print_to_text(song, file)
    else:
        print("Failed to retrieve the first line of HTML.")