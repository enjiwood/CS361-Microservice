To operate this microservice, follow these steps:

1) Start the mp3 player online application
2) Start the microservice desktop application
3) Load a song into the mp3 player
4) The microservice will read the mp3 file name from the localhost:3000
5) The microservice will then print the formatted and parsed title back into the song_name.txt